"""
Fast LDAP connection pool — drop-in replacement for ldappool with same API.
Pool logic is implemented in C++ for minimal acquire/release latency.
"""

from contextlib import contextmanager
import logging
import queue
import re
import time

import ldap
from ldap.ldapobject import ReconnectLDAPObject

try:
    from fast_ldap_pool._pool_core import SlotPool
except ImportError:
    SlotPool = None  # C++ extension not built; use Python fallback

log = logging.getLogger(__name__)


def _make_slot_pool(size: int):
    """Return C++ SlotPool if available, else a Python fallback with same API."""
    if SlotPool is not None:
        return SlotPool(size)
    # Pure Python fallback: queue of slot indices
    class _PySlotPool:
        __slots__ = ("_size", "_q", "_lock")

        def __init__(self, size: int):
            self._size = size
            self._q = queue.Queue()
            for i in range(size):
                self._q.put(i)

        def acquire(self) -> int:
            return self._q.get()

        def release(self, slot_id: int) -> None:
            if 0 <= slot_id < self._size:
                self._q.put(slot_id)

        def size(self) -> int:
            return self._size

    return _PySlotPool(size)


class MaxConnectionReachedError(Exception):
    """Raised when pool is full and no slot becomes available within retries."""
    pass


class BackendError(Exception):
    """LDAP backend error."""
    def __init__(self, msg, backend):
        self.backend = backend
        super().__init__(msg)


class StateConnector(ReconnectLDAPObject):
    """LDAP connector that tracks connection state (same semantics as ldappool)."""
    def __init__(self, *args, **kw):
        super().__init__(*args, **kw)
        self.connected = False
        self.who = ''
        self.cred = ''
        self._connection_time = None
        self.active = False

    def get_lifetime(self):
        if self._connection_time is None:
            return 0
        return time.time() - self._connection_time

    def simple_bind_s(self, who='', cred='', serverctrls=None, clientctrls=None):
        res = super().simple_bind_s(who, cred, serverctrls, clientctrls)
        self.connected = True
        self.who = who
        self.cred = cred
        if self._connection_time is None:
            self._connection_time = time.time()
        return res

    def unbind_ext_s(self, serverctrls=None, clientctrls=None):
        try:
            return super().unbind_ext_s(serverctrls, clientctrls)
        finally:
            self.connected = False
            self.who = None
            self.cred = None

    def add_s(self, *args, **kwargs):
        return self._apply_method_s(ReconnectLDAPObject.add_s, *args, **kwargs)

    def modify_s(self, *args, **kwargs):
        return self._apply_method_s(ReconnectLDAPObject.modify_s, *args, **kwargs)


class ConnectionManager:
    """
    LDAP connection pool with same API as ldappool.ConnectionManager.
    Uses a C++ slot pool for fast acquire/release.
    """
    def __init__(
        self,
        uri,
        bind=None,
        passwd=None,
        size=10,
        retry_max=3,
        retry_delay=0.1,
        use_tls=False,
        timeout=-1,
        connector_cls=StateConnector,
        use_pool=True,
        max_lifetime=600,
    ):
        self._slot_pool = _make_slot_pool(size) if use_pool else None
        self.size = size
        self.retry_max = retry_max
        self.retry_delay = retry_delay
        self.uri = uri
        self.bind = bind
        self.passwd = passwd
        self.use_tls = use_tls
        self.timeout = timeout
        self.connector_cls = connector_cls
        self.use_pool = use_pool
        self.max_lifetime = max_lifetime
        # Slot index -> connection (only when use_pool)
        self._connections = [None] * size if use_pool else None

    def _bind(self, conn, bind, passwd):
        if self.use_tls:
            conn.start_tls_s()
        if bind is not None:
            conn.simple_bind_s(bind, passwd)
        conn.active = True

    def _create_connector(self, bind, passwd):
        connected = False
        exc = None
        conn = None
        for server in re.split(r'[\s,]+', self.uri):
            tries = 0
            while tries < self.retry_max and not connected:
                try:
                    log.debug("Attempting to create connector to %s (attempt %d)", server, tries + 1)
                    conn = self.connector_cls(
                        server.strip(),
                        retry_max=self.retry_max,
                        retry_delay=self.retry_delay,
                    )
                    conn.timeout = self.timeout
                    self._bind(conn, bind, passwd)
                    connected = True
                except ldap.INVALID_CREDENTIALS as e:
                    exc = e
                    log.error("Invalid credentials", exc_info=True)
                    raise exc
                except ldap.LDAPError as e:
                    exc = e
                    tries += 1
                    if tries < self.retry_max:
                        log.info(
                            "Failure creating connector; will retry after %r seconds",
                            self.retry_delay,
                            exc_info=True,
                        )
                        time.sleep(self.retry_delay)
                    else:
                        log.error("Failure creating connector", exc_info=True)
            if connected:
                return conn
        if isinstance(exc, (ldap.NO_SUCH_OBJECT, ldap.SERVER_DOWN, ldap.TIMEOUT)):
            raise exc
        raise BackendError(str(exc), backend=conn)

    def _get_or_create_connection(self, slot_id, bind, passwd):
        conn = self._connections[slot_id]
        if conn is not None and conn.connected and conn.get_lifetime() <= self.max_lifetime:
            if conn.who == bind and conn.cred == passwd:
                conn.active = True
                return conn
        if conn is not None:
            try:
                conn.unbind_ext_s()
            except ldap.LDAPError:
                log.debug("Unbind on replace", exc_info=True)
        conn = self._create_connector(bind, passwd)
        self._connections[slot_id] = conn
        return conn

    def _get_connection(self, bind=None, passwd=None):
        bind = self.bind if bind is None else bind
        passwd = self.passwd if passwd is None else passwd
        if self.use_pool:
            slot_id = self._slot_pool.acquire()
            return slot_id, self._get_or_create_connection(slot_id, bind, passwd)
        conn = self._create_connector(bind, passwd)
        conn.active = True
        return None, conn

    def _release_connection(self, slot_id, connection):
        if self.use_pool:
            connection.active = False
            if not connection.connected:
                self._connections[slot_id] = None
            self._slot_pool.release(slot_id)
        else:
            connection.active = False
            try:
                connection.unbind_ext_s()
            except ldap.LDAPError:
                log.debug("Unbind on release", exc_info=True)

    @contextmanager
    def connection(self, bind=None, passwd=None):
        """
        Context manager that yields an LDAP connection (same interface as ldappool).
        """
        slot_id = None
        conn = None
        tries = 0
        while tries < self.retry_max:
            try:
                slot_id, conn = self._get_connection(bind, passwd)
                break
            except MaxConnectionReachedError:
                tries += 1
                time.sleep(0.1)
                if self.use_pool:
                    # Try to drop one inactive connection
                    for i in range(self.size):
                        c = self._connections[i]
                        if c is not None and not c.active:
                            try:
                                c.unbind_ext_s()
                            except ldap.LDAPError:
                                pass
                            self._connections[i] = None
                            self._slot_pool.release(i)
                            break
        if conn is None:
            raise MaxConnectionReachedError(self.uri)
        try:
            yield conn
        finally:
            self._release_connection(slot_id, conn)

    def __len__(self):
        if not self.use_pool or self._connections is None:
            return 0
        return sum(1 for c in self._connections if c is not None)


__all__ = ["ConnectionManager", "StateConnector", "MaxConnectionReachedError", "BackendError"]
